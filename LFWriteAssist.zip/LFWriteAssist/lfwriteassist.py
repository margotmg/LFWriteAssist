from siglas import siglas_list
from abreviaturas import abreviaturas_list
from palabras_alternativas import diccionario_facil
from long_words import count_syllables
from definiciones import definiciones_facil
from homonimas import homofonas_homografas
#import tkinter
import re
from text_splitter import split_text



#import language_check
import language_tool_python
from tkinter import *
import xml.etree.ElementTree as ET
#from alternative_woerter import basic_german
#from konjunktionen import Konjunktionen as bezugswoerter
import spacy 
#from stopwoerter import stop_woerter
import re
#from compound_split import doc_split
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.nlp.stemmers import Stemmer
from sumy.utils import get_stop_words
from sumy.summarizers.edmundson import EdmundsonSummarizer as Summarizer
import nltk
nltk.download('punkt')


class App:

    def __init__(self, window):

        # Colour of the application
        # Colour = '#e9d0af'
        Farbe = '#B0E0E6'

        # General window settings
        window.title('Soporte de autor Lectura Fácil')
        window.resizable(width=FALSE, height=FALSE)
        window.geometry("1250x660")

        # Instantiate a subwindow within the main window
        frame0 = Frame(window)
        frame0.pack(side=RIGHT)

        # Instantiate a subwindow within the subwindow
        frame0_0 = Frame(frame0)
        frame0_0.pack(side=TOP, expand=FALSE)

        # Instantiate a subwindow within the subwindow
        frame0_1 = Frame(frame0)
        frame0_1.pack(side=BOTTOM)

        # Instantiate a subwindow within the main window
        frame1 = Frame(window)
        frame1.pack()

        # Instantiate a subwindow within the main window
        frame2 = Frame(window)
        frame2.pack()

        # Instantiate a subwindow within the main window
        frame3 = Frame(window)
        frame3.pack()

        # Instantiate a subwindow within the main window
        frame4 = Frame(window)
        frame4.pack()

        # Instantiate a sliding bar for the selection list
        scrollbarY0 = Scrollbar(frame0_0)
        scrollbarY0.pack(side=RIGHT, fill=Y)

        # Instantiate a sliding bar for the selection list
        scrollbarX = Scrollbar(frame0_0)
        scrollbarX.pack(side=BOTTOM, fill=X)

        # Instantiate a scroll bar for the input text field
        scrollbarY1 = Scrollbar(frame1)
        scrollbarY1.pack(side=RIGHT, fill=Y)

        # Instantiate a scroll bar for the output text field
        scrollbarY2 = Scrollbar(frame2)
        scrollbarY2.pack(side=RIGHT, fill=Y)

        # Instantiate a scroll bar for the output text field
        scrollbarY3 = Scrollbar(frame3)
        scrollbarY3.pack(side=RIGHT, fill=Y)

        # Instantiate a heading for the rule list
        headlineRules = Label(frame0_0, text="Lista de normas")
        headlineRules.pack()

        # Instanziiere einen Canvas der die Auswahlkästen beinhalten wird
        self.canvas = Canvas(frame0_0, background="gray95", width=200, height=400)
        self.canvas.pack(side=TOP, fill="both", expand=FALSE)

        # Instantiate a canvas that will contain the selection boxes
        self.frame5 = Frame(self.canvas)
        self.frame5.pack()

        # Create the window of the canvas within the sub-window within the canvas
        self.canvas.create_window((4, 4), window=self.frame5, anchor="nw", tags="self.frame5")
        # Call the specified method for a configuration
        self.frame5.bind("<Configure>", self.configure_frame)

        # Instantiate an empty line
        leerzeile = Label(frame0_1, text="")
        leerzeile.pack()

        # Instantiate a heading for the slider
        headlineSlider = Label(frame0_1, text="Longitud del resumen en %")
        headlineSlider.pack()

        # Declare the attribute as a reciprocal variable for the slider
        self.scale = DoubleVar()
        # Set the default value of the reciprocal variable
        self.scale.set(50)
        # Instance a slider to control the length of the summary
        slider = Scale(frame0_1, from_=10, to=100, orient=HORIZONTAL, digits=2, resolution=10, variable=self.scale)
        slider.pack()

        # Assign a dictionary with the IDs of all rules to the attribute
        self.rule_status = self.get_rule_ids()

        # Instantiate a selection box for each entry in the dictionary containing the rule IDs
        for rule in self.rule_status:
            # Declare the value of a specific key as a reciprocal variable
            self.rule_status[rule] = IntVar()
            # Activate the selection box by default
            self.rule_status[rule].set(1)
            # Instantiate the selection box and link the respective value in the dictionary to the selection box
            # The value is 1 if the box is selected and 0 if not
            check = Checkbutton(self.frame5, text=rule, variable=self.rule_status[rule], background=Farbe)
            check.pack(anchor="w")

        # Connect the sliding bar with the selection list
        scrollbarY0.config(command=self.canvas.yview)
        self.canvas.config(yscrollcommand=scrollbarY0.set)

        # Connect the sliding bar with the selection list
        scrollbarX.config(command=self.canvas.xview, orient=HORIZONTAL)
        self.canvas.config(xscrollcommand=scrollbarX.set)

        # Instantiate a heading for the input field
        headline = Label(frame1, text="Campo de entrada")
        headline.pack()

        # Instantiate the input text field
        self.input = Text(frame1, bd=2, width=120, height=12, wrap=WORD)
        self.input.pack(side=TOP)

        # Connect the slide bar with the input text field
        scrollbarY1.config(command=self.input.yview)
        self.input.config(yscrollcommand=scrollbarY1.set)

        # Instantiate a heading for the output text field
        headline2 = Label(frame2, text="Resumido y revisado")
        headline2.pack()

        # Instantiate the output text field
        self.output = Text(frame2, bd=2, width=120, height=11, wrap=WORD, state=NORMAL)
        self.output.pack(side=BOTTOM)

        # Instantiate a heading for the output text field2
        headline3 = Label(frame3, text="Resumido y corregido automáticamente")
        headline3.pack()

        # Instantiate the output text field2
        self.output2 = Text(frame3, bd=2, width=120, height=11, wrap=WORD, state=NORMAL)
        self.output2.pack(side=TOP)

        # Connect the slide bar with the output text field2
        scrollbarY3.config(command=self.output2.yview)
        self.output2.config(yscrollcommand=scrollbarY3.set)

        # Connect the slide bar with the output text field
        scrollbarY2.config(command=self.output.yview)
        self.output.config(yscrollcommand=scrollbarY2.set)

        # Instantiate a button which finds the errors in the text when clicked
        submit = Button(frame4, text = "Corregir", command = self.summarize_and_correct)
        submit.pack(side="right")

        # Instantiate a button which summarises and corrects the text when clicked
        submit2 = Button(frame4, text="Resumir y revisar", command=self.summarize_and_proof)
        submit2.pack(side="left")

        window.configure(background=Farbe)
        frame0.configure(background=Farbe)
        frame0_0.configure(background=Farbe)
        frame0_1.configure(background=Farbe)
        frame1.configure(background=Farbe)
        frame2.configure(background=Farbe)
        frame3.configure(background=Farbe)
        frame4.configure(background=Farbe)
        headlineRules.configure(background=Farbe)
        self.canvas.configure(background=Farbe)
        self.frame5.configure(background=Farbe)
        leerzeile.configure(background=Farbe)
        headlineSlider.configure(background=Farbe)
        slider.configure(background=Farbe)
        headline.configure(background=Farbe)
        headline2.configure(background=Farbe)
        headline3.configure(background=Farbe)
        submit.configure(background=Farbe)
        submit2.configure(background=Farbe)

###########################################################

###########################################################
    def configure_frame(self, event):
        # Reset the scroll region to take the inner window into account
        # Assign the size of the subwindow to the scroll region so that it corresponds to the size of the subwindow
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def find_errors(self, text):

        # Spacy initialisieren
        nlp = spacy.load("es_core_news_sm", disable=["parser", "ner"])

        # Instantiate a LanguageTool object with the specified rule set
        tool = language_tool_python.LanguageTool('es')
        # Check the specified text for errors based on the rule set
        result = tool.check(text)

        # Declare the variable that will contain the result
        errors = ""

        # Add all errors found to the variable
        for n in result:
            for rule in self.rule_status:
                # Check whether the ID of an error found matches the ID from the dictionary
                if n.ruleId == rule:
                    # Add the error found to the variable if the corresponding selection box is activated
                    if self.rule_status[rule].get() == 1:
                        errors += str(n) + "\n"

        # ALTERNATIVAS rule (proposes easier synonyms)
        if self.rule_status["ALTERNATIVAS"].get() == 1:
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if token.text in list(diccionario_facil.keys()):
                    errors += "Rule ID: ALTERNATIVAS" + "\n" + "Mensaje: Esta palabra tiene un sinónimo más adecuado para la Lectura Fácil." + "\n" + "Palabra encontrada: " + str(
                        token.text) + "\n" + "Alternativa: " + str(diccionario_facil[token.text]) + "\n" + "\n"
        
                        
       # SIGLAS rule (provides expansions for acronyms) 
        if self.rule_status["SIGLAS"].get() == 1:
            # Segmenting the input text into words
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if token.text in list(siglas_list.keys()):
                    errors += "Rule ID: SIGLAS" + "\n" + "Mensaje: Se debería evitar el uso de siglas. Añade su definición." + "\n" + "Sigla econtrada: " + str(
                        token.text) + "\n" + "Tal vez querías decir: " + str(siglas_list[token.text]) + "\n" + "\n"
                
        # ABREVIATURAS rule (provides full words for shortened forms)
        if self.rule_status["ABREVIATURAS"].get() == 1:
            # Segmenting the input text into words
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if token.text in list(abreviaturas_list.keys()):
                    errors += "Rule ID: ABREVIATURAS" + "\n" + "Mensaje: Se debería evitar el uso de abreviaturas. Añade su definición." + "\n" + "Abreviatura econtrada: " + str(
                        token.text) + "\n" + "Tal vez querías decir: " + str(abreviaturas_list[token.text]) + "\n" + "\n"



        # HOMÓNIMAS rule (detects homonyms)
        if self.rule_status["HOMÓNIMAS"].get() == 1:
            # Segmenting the input text into words
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if token.text in list(homofonas_homografas.keys()):
                    errors += "Rule ID: HOMÓNIMAS" + "\n" + "Mensaje: Si se utilizan palabras con el mismo sonido o la misma grafía (palabras homófonas u homógrafas), pero con varios significados, se debe redactar el texto de modo que facilite inequívocamente la comprensión del mismo." + "\n" + "Abreviatura econtrada: " + str(
                        token.text) + "\n" + "Esta palabra se puede confundir con: " + str(homofonas_homografas[token.text]) + "\n" + "\n"

                    
                
        # DEFINICIONES rule (provides definitions for certain words)
        if self.rule_status["DEFINICIONES"].get() == 1:
            # Segmenting the input text into words
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if token.text in list(definiciones_facil.keys()):
                    errors += "Rule ID: DEFINICIONES" + "\n" + "Mensaje: Puede que esta palabra sea demasiado complicada. Puedes añadir su definición" + "\n" + "Palabra econtrada: " + str(
                        token.text) + "\n" + "Definición(es): " + str(definiciones_facil[token.text]) + "\n" + "\n"

                    
        # PALABRAS LARGAS rule (detecets when a word is too long)
        if self.rule_status["PALABRAS LARGAS"].get() == 1:
            doc = nlp(self.input.get(1.0, END))
            # Iterate through all the words
            for token in doc:
                if count_syllables(token.text) >= 6:
                    #print(f"Warning: Found a long word '{token.text}'")
                    errors += "Rule ID: PALABRAS LARGAS" + "\n" + "Mensaje: Esta palabra es demasiado larga:" + str(token.text) + "\n"+ "Intenta evitar el uso de palabras largas." + "\n" + "\n"


        # FRASES LARGAS rule (detects when a sentence is too long)
        if self.rule_status ["FRASES LARGAS"].get() == 1:
            doc = nlp(self.input.get(1.0, END))
            sentences = re.split(r' *[\.\?!][\'"\)\]]* *', text)
            for sentence in sentences:
                words = sentence.split()
                if len(words) > 10:
                    errors += "Rule ID: FRASES LARGAS" + "\n" + "Mensaje: Esta frase tiene más de 10 palabras:" + str(sentence) + "\n"+ "Considera acortar la frase." + "\n" + "\n"



        #Frases con DOBLE NEGACIÓN (detects if a sentence has a double negation)
  
        if "sentencizer" not in nlp.pipe_names:
            nlp.add_pipe("sentencizer")
        negation_adverbs = ["no", "tampoco", "nunca", "jamás", "ni", "ningún", "ninguno", "ninguna"]

        if self.rule_status["DOBLE NEGACIÓN"].get() == 1:
            doc = nlp(self.input.get(1.0, END))
            for sentence in doc.sents:
                negation_count = sum(1 for token in sentence if token.text.lower() in negation_adverbs)
                if negation_count > 1:
                    errors += f"Rule ID: DOBLE NEGACIÓN\nMensaje: Esta frase contiene más de una negación: '{sentence.text}'.\nConsidera reformular la frase.\n\n"




        
                  
                 
        # Display the status of the selection boxes in the terminal
        for n in self.rule_status:
            print(str(n) + ": " + str(self.rule_status[n].get()))

        return errors

    def get_rule_ids(self):

        # Parse XML document 
        tree = ET.parse('grammar.xml')
        # Determine the root element of the XML file
        root = tree.getroot()

        # Declare a list for the rules
        rule_list = []

        # Iterate through the sub-elements
        for child in root:
            # Iterate through the sub-elements of the sub-elements
            for grandchild in child:
                # Assign the attribute values of the id attribute to a list
                rule_list.append(grandchild.attrib["id"])

        # Assign special rules as these do not occur in the XML document
        rule_list.append("SIGLAS")
        rule_list.append("ALTERNATIVAS")
        rule_list.append("ABREVIATURAS")
        rule_list.append("HOMÓNIMAS")
        rule_list.append("DEFINICIONES")
        rule_list.append("PALABRAS LARGAS")
        rule_list.append("FRASES LARGAS")
        rule_list.append("DOBLE NEGACIÓN")

        # Transformation of the list with the rules into a dictionary
        # The values of the rules represent whether a rule is activated or not -> 0 for deactivated and 1 for activated
        rule_status = {rule: 0 for (rule) in rule_list}

        # Return the resulting dictionary
        return rule_status

 
    def summarize(self, text):

        # Initialise Spacy
        nlp = spacy.load("es_core_news_sm", disable=["parser", "ner"])

        # Segment the input text into words
        doc = nlp(text)

        # Declare a dictionary to record the number of all different words
        wortanzahl = dict()

        # Iterate through all the words in the text
        for token in doc:
            lemma = token.lemma_
            # Terminate the current iteration if the word is a stop word
            if lemma in stop_woerter:
                continue

            # If a word is already in the dictionary, the number of words is increased by 1
            if lemma in wortanzahl:
                wortanzahl[lemma] += 1
            # If a word does not yet exist in the dictionary, a new entry is created and the number is set to 1
            else:
                wortanzahl[lemma] = 1

        # Break the text into sentences according to these rules:
        # (?<!\w\.\w.)\s -> No separation if two characters with a dot in the middle and at the end precede the space (e.g. etc.)
        # (?<![0-9]\.)\s -> No separation if a number following a dot precedes the space (9. etc.)
        # (?<![0-9][0-9]\.)\s -> No separation if two numbers following a dot precede the space (18. etc.)
        # (?<![A-Z]\.) -> No separation if a capital letter followed by a full stop precedes the space (W. etc)
        # (?<![A-Z][a-z]\.)\s -> No separation if a capital letter followed by a lowercase letter and a full stop precede the space (Dr. etc)
        # (?<=\.|\?|\!)\s -> Separate if a full stop, question mark or exclamation mark precedes the space
        saetze = re.split(r"(?<!\w\.\w.)(?<![0-9]\.)(?<![0-9][0-9]\.)(?<![A-Z]\.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s", text)

        # Declare a dictionary to record the value of a sentence
        # The value of a sentence is the sum of the number of words in that sentence
        satzwerte = dict()

        # Iterate through all the sentences and check which words appear in the sentence
        for satz in saetze:
            for wort, anzahl in wortanzahl.items():
                if wort in satz.lower():
                    # If a sentence is already in the dictionary, the value of the sentence is increased by the number of the corresponding word
                    if satz in satzwerte:
                        satzwerte[satz] += anzahl
                    # If a sentence is not in the dictionary, a new entry is created and the value of the sentence is set to the number of the word
                    else:
                        satzwerte[satz] = anzahl

        # Declare the variable which will contain the sum of the values of all records
        summe_satzwerte = 0

        # Add the value of this record to the variable for each record
        for satz in satzwerte:
            summe_satzwerte += satzwerte[satz]

        # Divide the sum of all record values by the number of records to get the average record value
        mittelwert = int(summe_satzwerte / len(satzwerte))

        # Declare the variable that will contain the resulting summary
        zusammenfassung = ""

        # Declare the variable that will hold the previous record in the loop
        vorheriger_satz = ""

        # Check for each record whether its value exceeds the defined limit
        for satz in saetze:
            if (satz in satzwerte) and (satzwerte[satz] > mittelwert):
                # Segment the sentence into words to access the first word
                doc = nlp(satz)
                # If the variable contains the previous sentence and if the first word of the sentence occurs in the list of reference words, the sentence is added to the result
                if (vorheriger_satz != "") and (doc[0].text.lower() in bezugswoerter):
                    zusammenfassung += " " + vorheriger_satz
                # Add the current record to the result if its value exceeds the limit
                zusammenfassung += " " + satz + "\n\n"
                # Assign an empty string to the variable if the current record has already been added to the result
                vorheriger_satz = ""
            # Assign the current record to the variable so that it can be used in the next iteration if the record has not been added to the result
            else:
                vorheriger_satz = satz

        # Paste the summary into the output text field
        return zusammenfassung

    def edmunson(self, text):

        # Choose language
        language = "spanish"
        # Drag the percentage from the slider
        divident = 100 / self.scale.get()

        # Tokenise the text and add a stemmer to the summariser
        parser = PlaintextParser.from_string(text, Tokenizer(language))
        stemmer = Stemmer(language)
        summarizer = Summarizer(stemmer)

        # Define specific word lists
        # The bonus, stigma and null words should not be used but no empty input is accepted
        summarizer.stop_words = get_stop_words(language)
        summarizer.bonus_words = ["nsdgdf"]
        summarizer.stigma_words = ["mtrtf"]
        summarizer.null_words = ["zngg"]

        summary = ""
        count = 0

        # Count the number of sentences
        for sentence in summarizer(parser.document, 10000000000):
            count += 1

        # Determine the number of records from the percentage
        sentence_number = round(count / divident)

        # DPut the sentences together to form a text
        for sentence in summarizer(parser.document, sentence_number):
            summary += " " + str(sentence)

        return summary


    

    def correct(self, text):
        tool = language_tool_python.LanguageTool('es')
        matches = tool.check(text)
        corrections = []
        underlines = []

        length_difference = 0

        for match in matches:
            start = match.offset + length_difference
            end = start + match.errorLength
            error_text = text[start:end]

            if match.replacements:
                replacement = match.replacements[0]
                corrections.append((start, end, replacement))
                text = text[:start] + replacement + text[end:]
                length_difference += len(replacement) - len(error_text)
            else:
                underlines.append((start, end))
               

        return text, corrections, underlines





##################
    
        # Example function where you process the text and apply the rules
    #def apply_rules_and_display(text):
        # ... your existing code to process the text and apply the rules ...

        # Let's say 'rule_results' is a list of tuples with the format (rule_name, start_index, end_index)
    #    rule_results = process_text_with_rules(text)

        # Display the text in the Text widget
    #    text_widget.delete("1.0", END)
    #    text_widget.insert("1.0", text)

        # Underline the text based on the rule results
    #    for rule_name, start, end in rule_results:
    #        text_widget.tag_add("underline", start, end)

        # Configure the 'underline' tag to underline text
    #    text_widget.tag_configure("underline", underline=True)


#############

    
    # Apply underlining in the text
    def apply_underlining(self, text_widget, corrected_positions, uncorrected_positions):
        # Apply style for corrected (green) and uncorrected parts (orange)
        text_widget.tag_configure("corrected", background="lightgreen")
        text_widget.tag_configure("uncorrected", background="orange")

        for start, end, _ in corrected_positions:
            text_widget.tag_add("corrected", f"1.0 + {start} chars", f"1.0 + {end} chars")

        for start, end in uncorrected_positions:
            text_widget.tag_add("uncorrected", f"1.0 + {start} chars", f"1.0 + {end} chars")


    
    def summarize_and_correct(self):
        text = self.input.get(1.0, END)
        self.output2.delete(1.0, END)

        summary = self.edmunson(text)
        corrected_text, corrected_positions, uncorrected_positions = self.correct(summary)

        # Insert the corrected text
        self.output2.insert(END, corrected_text)

        # Apply underlining
        self.apply_underlining(self.output2, corrected_positions, uncorrected_positions)



            
    def summarize_and_proof(self):

        # Assign the input text to a variable
        text = self.input.get(1.0, END)
        # Empty the content of the output text field
        self.output.delete(1.0, END)

        summary = self.edmunson(text)
        errors = self.find_errors(summary)

        result = summary + "\n\n" + errors

        # Paste the result into the output text field
        self.output.insert(END, result)










#def write_output_to_file(output_text, file_name="output.txt"):
#    with open(file_name, 'w', encoding='utf-8') as file:
#        file.write(output_text)
        #print(f"File '{file_name}' has been created.")

#if __name__ == "__main__":
#    root = tkinter.Tk()  # Create the main window
#    app = App(root)  # Pass the main window to the App class

#    app.summarize_and_correct()  # Call the summarize_and_proof method

        # Debugging: Print the content of self.output to confirm it's populated
#    final_output = app.output.get("1.0", "end-1c")  # Gets text from the widget
#    print("Debug - Final Output:", final_output)

        # Write the output to a file only if it's not empty
#    if final_output.strip():
#        write_output_to_file(final_output)
#    else:
#        print("No text to write to file.")

#    root.mainloop()  # Start the Tkinter event loop






# Create an empty window
window = Tk()

# Call up the constructor function
app = App(window)

# Display the window continuously on the screen. Otherwise, the window would only be displayed briefly and then immediately closed again
window.mainloop()





