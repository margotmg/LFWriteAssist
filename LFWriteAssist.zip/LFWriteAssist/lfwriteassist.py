import re
import threading
import xml.etree.ElementTree as ET
from tkinter import (
    BOTTOM, DISABLED, END, FALSE, HORIZONTAL, NORMAL, RIGHT, TOP, WORD, X, Y,
    Button, Canvas, Checkbutton, DoubleVar, Frame, IntVar, Label,
    Scale, Scrollbar, Text, Tk, Toplevel,
)
from tkinter import filedialog

import language_tool_python
import nltk
import spacy
from sumy.nlp.stemmers import Stemmer
from sumy.nlp.tokenizers import Tokenizer
from sumy.parsers.plaintext import PlaintextParser
from sumy.summarizers.edmundson import EdmundsonSummarizer as Summarizer
from sumy.utils import get_stop_words

from abreviaturas import abreviaturas_list
from definiciones import definiciones_facil
from homonimas import homofonas_homografas
from long_words import count_syllables
from palabras_alternativas import diccionario_facil
from siglas import siglas_list

nltk.download("punkt", quiet=True)

BG_COLOR = "#B0E0E6"

NEGATION_ADVERBS = {"no", "tampoco", "nunca", "jamás", "ni", "ningún", "ninguno", "ninguna"}

# Dictionary-based rules: (rule_id, message, word_label, suggestion_label, dictionary)
DICT_RULES = [
    ("ALTERNATIVAS",
     "Esta palabra tiene un sinónimo más adecuado para la Lectura Fácil.",
     "Palabra encontrada", "Alternativa", diccionario_facil),
    ("SIGLAS",
     "Se debería evitar el uso de siglas. Añade su definición.",
     "Sigla encontrada", "Tal vez querías decir", siglas_list),
    ("ABREVIATURAS",
     "Se debería evitar el uso de abreviaturas. Añade su definición.",
     "Abreviatura encontrada", "Tal vez querías decir", abreviaturas_list),
    ("HOMÓNIMAS",
     "Si se utilizan palabras con el mismo sonido o la misma grafía "
     "(palabras homófonas u homógrafas), pero con varios significados, se debe "
     "redactar el texto de modo que facilite inequívocamente la comprensión del mismo.",
     "Palabra encontrada", "Esta palabra se puede confundir con", homofonas_homografas),
    ("DEFINICIONES",
     "Puede que esta palabra sea demasiado complicada. Puedes añadir su definición.",
     "Palabra encontrada", "Definición(es)", definiciones_facil),
]


class App:

    def __init__(self, window):
        self.window = window
        self._tooltip = None

        window.title("Soporte de autor Lectura Fácil")
        window.resizable(width=FALSE, height=FALSE)
        window.geometry("1250x660")

        # Frames
        frame0 = Frame(window, bg=BG_COLOR)
        frame0.pack(side=RIGHT)

        frame0_top = Frame(frame0, bg=BG_COLOR)
        frame0_top.pack(side=TOP, expand=FALSE)

        frame0_bottom = Frame(frame0, bg=BG_COLOR)
        frame0_bottom.pack(side=BOTTOM)

        frame_input = Frame(window, bg=BG_COLOR)
        frame_input.pack()

        frame_output1 = Frame(window, bg=BG_COLOR)
        frame_output1.pack()

        frame_output2 = Frame(window, bg=BG_COLOR)
        frame_output2.pack()

        frame_buttons = Frame(window, bg=BG_COLOR)
        frame_buttons.pack()

        # Scrollbars
        scrollbar_y0 = Scrollbar(frame0_top)
        scrollbar_y0.pack(side=RIGHT, fill=Y)

        scrollbar_x0 = Scrollbar(frame0_top)
        scrollbar_x0.pack(side=BOTTOM, fill=X)

        scrollbar_y1 = Scrollbar(frame_input)
        scrollbar_y1.pack(side=RIGHT, fill=Y)

        scrollbar_y2 = Scrollbar(frame_output1)
        scrollbar_y2.pack(side=RIGHT, fill=Y)

        scrollbar_y3 = Scrollbar(frame_output2)
        scrollbar_y3.pack(side=RIGHT, fill=Y)

        # Rule list with scrollable canvas
        Label(frame0_top, text="Lista de normas", bg=BG_COLOR).pack()

        self.canvas = Canvas(frame0_top, bg=BG_COLOR, width=200, height=400)
        self.canvas.pack(side=TOP, fill="both", expand=FALSE)

        self.frame_rules = Frame(self.canvas, bg=BG_COLOR)
        self.frame_rules.pack()

        self.canvas.create_window((4, 4), window=self.frame_rules, anchor="nw")
        self.frame_rules.bind("<Configure>", self._on_frame_configure)

        scrollbar_y0.config(command=self.canvas.yview)
        self.canvas.config(yscrollcommand=scrollbar_y0.set)

        scrollbar_x0.config(command=self.canvas.xview, orient=HORIZONTAL)
        self.canvas.config(xscrollcommand=scrollbar_x0.set)

        # Summary length slider
        Label(frame0_bottom, text="", bg=BG_COLOR).pack()
        Label(frame0_bottom, text="Longitud del resumen en %", bg=BG_COLOR).pack()

        self.scale = DoubleVar(value=50)
        Scale(frame0_bottom, from_=10, to=100, orient=HORIZONTAL, digits=2,
              resolution=10, variable=self.scale, bg=BG_COLOR).pack()

        # Rule checkboxes
        self.rule_status = self._load_rule_ids()
        for rule in self.rule_status:
            self.rule_status[rule] = IntVar(value=1)
            Checkbutton(self.frame_rules, text=rule, variable=self.rule_status[rule],
                        bg=BG_COLOR).pack(anchor="w")

        # Input field
        Label(frame_input, text="Campo de entrada", bg=BG_COLOR).pack()
        self.input = Text(frame_input, bd=2, width=120, height=12, wrap=WORD)
        self.input.pack(side=TOP)
        scrollbar_y1.config(command=self.input.yview)
        self.input.config(yscrollcommand=scrollbar_y1.set)

        # Output field 1: summarized + proofread
        Label(frame_output1, text="Resumido y revisado", bg=BG_COLOR).pack()
        self.output = Text(frame_output1, bd=2, width=120, height=11, wrap=WORD, state=NORMAL)
        self.output.pack(side=BOTTOM)
        scrollbar_y2.config(command=self.output.yview)
        self.output.config(yscrollcommand=scrollbar_y2.set)

        # Output field 2: summarized + auto-corrected
        Label(frame_output2, text="Resumido y corregido automáticamente", bg=BG_COLOR).pack()
        self.output2 = Text(frame_output2, bd=2, width=120, height=11, wrap=WORD, state=NORMAL)
        self.output2.pack(side=TOP)
        scrollbar_y3.config(command=self.output2.yview)
        self.output2.config(yscrollcommand=scrollbar_y3.set)

        # Buttons
        btn_load = Button(frame_buttons, text="Importar", command=self._load_file,
                          bg=BG_COLOR)
        btn_load.pack(side="left")
        btn_proof = Button(frame_buttons, text="Resumir y revisar", command=self.summarize_and_proof,
                           bg=BG_COLOR)
        btn_proof.pack(side="left")
        btn_correct = Button(frame_buttons, text="Resumir y Corregir", command=self.summarize_and_correct,
                             bg=BG_COLOR)
        btn_correct.pack(side="left")
        btn_save = Button(frame_buttons, text="Guardar", command=self._save_output,
                          bg=BG_COLOR)
        btn_save.pack(side="left")
        self._buttons = [btn_load, btn_proof, btn_correct, btn_save]

        window.configure(bg=BG_COLOR)

        # Show loading overlay
        loading_label = Label(window, text="Cargando modelos de lenguaje...",
                              bg="white", font=("Helvetica", 16))
        loading_label.place(relx=0.5, rely=0.5, anchor="center")
        loading_label.lift()
        window.update()

        # Load NLP tools once at startup
        self.nlp = spacy.load("es_core_news_sm", disable=["parser", "ner"])
        self.nlp.add_pipe("sentencizer")
        self.lang_tool = language_tool_python.LanguageTool("es")

        loading_label.destroy()

    # -- Internal helpers --

    def _on_frame_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _load_rule_ids(self):
        tree = ET.parse("grammar.xml")
        root = tree.getroot()
        rule_list = [
            grandchild.attrib["id"]
            for child in root
            for grandchild in child
        ]
        rule_list.extend([
            "SIGLAS", "ALTERNATIVAS", "ABREVIATURAS", "HOMÓNIMAS",
            "DEFINICIONES", "PALABRAS LARGAS", "FRASES LARGAS", "DOBLE NEGACIÓN",
            "SALTO DE LÍNEA",
        ])
        return {rule: 0 for rule in rule_list}

    # -- Threading --

    def _run_async(self, work_fn, callback_fn):
        self._disable_buttons()

        def target():
            try:
                result = work_fn()
                self.window.after(0, lambda: self._async_done(callback_fn, result))
            except Exception as e:
                self.window.after(0, lambda err=str(e): self._async_error(err))

        threading.Thread(target=target, daemon=True).start()

    def _disable_buttons(self):
        for btn in self._buttons:
            btn.configure(state=DISABLED)

    def _enable_buttons(self):
        for btn in self._buttons:
            btn.configure(state=NORMAL)

    def _async_done(self, callback_fn, result):
        callback_fn(result)
        self._enable_buttons()

    def _async_error(self, error_msg):
        self._enable_buttons()
        self.output.delete(1.0, END)
        self.output.insert(END, f"Error: {error_msg}")

    # -- Tooltip management --

    def _setup_tooltips(self, widget, errors):
        self._clear_tooltips(widget)
        widget._tooltip_errors = {}
        widget._last_tip_tags = set()

        for i, error in enumerate(errors):
            tag_name = f"err_{i}"
            self._add_tag_skip_newlines(widget, tag_name,
                                        error["start"], error["end"])
            widget._tooltip_errors[tag_name] = error

        widget.bind("<Motion>", lambda e, w=widget: self._on_text_motion(e, w))
        widget.bind("<Leave>", lambda e: self._hide_tooltip())

    def _on_text_motion(self, event, widget):
        index = widget.index(f"@{event.x},{event.y}")
        tags = set(t for t in widget.tag_names(index) if t.startswith("err_"))

        if tags == getattr(widget, '_last_tip_tags', set()):
            return

        widget._last_tip_tags = tags

        if not tags:
            self._hide_tooltip()
            return

        messages = []
        for tag in sorted(tags):
            error = getattr(widget, '_tooltip_errors', {}).get(tag)
            if error:
                messages.append(error["message"])

        self._show_tooltip(widget, "\n---\n".join(messages), event.x_root, event.y_root)

    def _show_tooltip(self, widget, text, x, y):
        self._hide_tooltip()
        self._tooltip = Toplevel(widget)
        self._tooltip.wm_overrideredirect(True)
        self._tooltip.wm_geometry(f"+{x + 15}+{y + 10}")
        Label(self._tooltip, text=text, background="#ffffe0",
              relief="solid", borderwidth=1, justify="left",
              wraplength=400).pack()

    def _hide_tooltip(self):
        if self._tooltip:
            self._tooltip.destroy()
            self._tooltip = None

    def _clear_tooltips(self, widget):
        for tag in list(widget.tag_names()):
            if tag.startswith("err_"):
                widget.tag_delete(tag)
        widget.unbind("<Motion>")
        widget.unbind("<Leave>")

    # -- Import / Export --

    def _load_file(self):
        filepath = filedialog.askopenfilename(
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if filepath:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
            self.input.delete(1.0, END)
            self.input.insert(END, content)

    def _save_output(self):
        text1 = self.output.get(1.0, END).strip()
        text2 = self.output2.get(1.0, END).strip()

        if not text1 and not text2:
            return

        parts = []
        if text2:
            parts.append(text2)
        if text1:
            parts.append(text1)
        content = "\n\n".join(parts)

        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if filepath:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

    # -- Error detection --

    def _detect_custom_errors(self, text):
        doc = self.nlp(text)
        errors = []

        # Dictionary-based rules with lemma matching
        for rule_id, message, word_label, suggestion_label, dictionary in DICT_RULES:
            if self.rule_status[rule_id].get() == 1:
                for token in doc:
                    match_key = None
                    if token.text in dictionary:
                        match_key = token.text
                    elif token.lemma_ in dictionary:
                        match_key = token.lemma_
                    if match_key is not None:
                        errors.append({
                            "start": token.idx,
                            "end": token.idx + len(token.text),
                            "rule_id": rule_id,
                            "message": (
                                f"Rule ID: {rule_id}\n"
                                f"Mensaje: {message}\n"
                                f"{word_label}: {token.text}\n"
                                f"{suggestion_label}: {dictionary[match_key]}\n"
                            ),
                        })

        # Long words
        if self.rule_status["PALABRAS LARGAS"].get() == 1:
            for token in doc:
                if count_syllables(token.text) >= 6:
                    errors.append({
                        "start": token.idx,
                        "end": token.idx + len(token.text),
                        "rule_id": "PALABRAS LARGAS",
                        "message": (
                            f"Rule ID: PALABRAS LARGAS\n"
                            f"Mensaje: Esta palabra es demasiado larga: {token.text}\n"
                            f"Intenta evitar el uso de palabras largas.\n"
                        ),
                    })

        # Long sentences (using spacy sentencizer for consistency)
        if self.rule_status["FRASES LARGAS"].get() == 1:
            for sent in doc.sents:
                if len(sent.text.split()) > 10:
                    errors.append({
                        "start": sent.start_char,
                        "end": sent.end_char,
                        "rule_id": "FRASES LARGAS",
                        "message": (
                            f"Rule ID: FRASES LARGAS\n"
                            f"Mensaje: Esta frase tiene más de 10 palabras: {sent.text}\n"
                            f"Considera acortar la frase.\n"
                        ),
                    })

        # Double negation
        if self.rule_status["DOBLE NEGACIÓN"].get() == 1:
            for sentence in doc.sents:
                neg_tokens = [t for t in sentence if t.text.lower() in NEGATION_ADVERBS]
                if len(neg_tokens) > 1:
                    for t in neg_tokens:
                        errors.append({
                            "start": t.idx,
                            "end": t.idx + len(t.text),
                            "rule_id": "DOBLE NEGACIÓN",
                            "message": (
                                f"Rule ID: DOBLE NEGACIÓN\n"
                                f"Mensaje: Esta frase contiene más de una negación: "
                                f"'{sentence.text}'.\n"
                                f"Considera reformular la frase.\n"
                            ),
                        })

        return errors

    def _detect_all_errors(self, text):
        errors = []

        # LanguageTool grammar checks
        matches = self.lang_tool.check(text)
        for match in matches:
            if match.ruleId in self.rule_status and self.rule_status[match.ruleId].get() == 1:
                errors.append({
                    "start": match.offset,
                    "end": match.offset + match.errorLength,
                    "rule_id": match.ruleId,
                    "message": str(match),
                })

        # Custom rule errors
        errors.extend(self._detect_custom_errors(text))

        return errors

    # -- NLP processing --

    def edmunson(self, text):
        language = "spanish"
        divident = 100 / self.scale.get()

        parser = PlaintextParser.from_string(text, Tokenizer(language))
        stemmer = Stemmer(language)
        summarizer = Summarizer(stemmer)

        summarizer.stop_words = get_stop_words(language)
        summarizer.bonus_words = ["nsdgdf"]
        summarizer.stigma_words = ["mtrtf"]
        summarizer.null_words = ["zngg"]

        sentence_count = len(parser.document.sentences)
        sentence_number = round(sentence_count / divident)

        return " ".join(str(s) for s in summarizer(parser.document, sentence_number))

    def correct(self, text):
        matches = self.lang_tool.check(text)
        corrections = []
        uncorrected = []
        length_difference = 0

        for match in matches:
            start = match.offset + length_difference
            end = start + match.errorLength
            error_text = text[start:end]

            if match.replacements:
                replacement = match.replacements[0]
                new_end = start + len(replacement)
                corrections.append((start, new_end, replacement))
                text = text[:start] + replacement + text[end:]
                length_difference += len(replacement) - len(error_text)
            else:
                uncorrected.append({
                    "start": start,
                    "end": end,
                    "rule_id": match.ruleId,
                    "message": str(match),
                })

        return text, corrections, uncorrected

    # -- Multi-error detection --

    def _find_multi_error_spans(self, all_spans, text_length):
        if not all_spans or text_length == 0:
            return []

        counts = [0] * text_length
        for start, end in all_spans:
            for i in range(start, min(end, text_length)):
                counts[i] += 1

        multi_spans = []
        i = 0
        while i < text_length:
            if counts[i] >= 2:
                start = i
                while i < text_length and counts[i] >= 2:
                    i += 1
                multi_spans.append((start, i))
            else:
                i += 1

        return multi_spans

    # -- Highlighting --

    def _add_tag_skip_newlines(self, widget, tag_name, start, end):
        """Add a tag to a text widget, splitting around newline characters.

        In tkinter, tagging a \\n causes the highlight to fill the rest of
        the visual line.  Splitting the span at every newline avoids this.
        """
        text = widget.get("1.0", END)
        seg_start = start
        for i in range(start, min(end, len(text))):
            if text[i] == "\n":
                if seg_start < i:
                    widget.tag_add(tag_name,
                                   f"1.0 + {seg_start} chars",
                                   f"1.0 + {i} chars")
                seg_start = i + 1
        if seg_start < end:
            widget.tag_add(tag_name,
                           f"1.0 + {seg_start} chars",
                           f"1.0 + {end} chars")

    def apply_underlining(self, text_widget, corrected_positions, uncorrected_positions,
                          multi_error_positions=None):
        text_widget.tag_configure("corrected", background="lightgreen")
        text_widget.tag_configure("uncorrected", background="orange")
        text_widget.tag_configure("multi_error", background="#d85f5f")

        for start, end, _ in corrected_positions:
            self._add_tag_skip_newlines(text_widget, "corrected", start, end)

        for start, end in uncorrected_positions:
            self._add_tag_skip_newlines(text_widget, "uncorrected", start, end)

        if multi_error_positions:
            for start, end in multi_error_positions:
                self._add_tag_skip_newlines(text_widget, "multi_error", start, end)
            text_widget.tag_raise("multi_error")

    # -- Main actions --

    def summarize_and_correct(self):
        text = self.input.get(1.0, END)
        self.output2.delete(1.0, END)
        self._clear_tooltips(self.output2)
        self.output2.insert(END, "Procesando...")

        def work():
            summary = self.edmunson(text)
            corrected_text, corrections, uncorrected = self.correct(summary)
            custom_errors = self._detect_custom_errors(corrected_text)
            return corrected_text, corrections, uncorrected, custom_errors

        def callback(result):
            corrected_text, corrections, uncorrected, custom_errors = result
            self.output2.delete(1.0, END)

            if self.rule_status["SALTO DE LÍNEA"].get() == 1:
                corrected_text = corrected_text.replace(". ", ".\n")

            self.output2.insert(END, corrected_text)

            _SKIP_HIGHLIGHT = {"FRASES LARGAS", "ALTERNATIVAS", "DEFINICIONES"}
            highlight_spans = (
                [(e["start"], e["end"]) for e in uncorrected] +
                [(e["start"], e["end"]) for e in custom_errors
                 if e["rule_id"] not in _SKIP_HIGHLIGHT]
            )
            long_sent_spans = [(e["start"], e["end"]) for e in custom_errors
                               if e["rule_id"] == "FRASES LARGAS"]
            multi = self._find_multi_error_spans(highlight_spans, len(corrected_text))

            self.apply_underlining(self.output2, corrections, highlight_spans, multi)

            self.output2.tag_configure("long_sentence", underline=True)
            for start, end in long_sent_spans:
                self._add_tag_skip_newlines(self.output2, "long_sentence", start, end)

            self._setup_tooltips(self.output2, uncorrected + custom_errors)

        self._run_async(work, callback)

    def summarize_and_proof(self):
        text = self.input.get(1.0, END)
        self.output.delete(1.0, END)
        self._clear_tooltips(self.output)
        self.output.insert(END, "Procesando...")

        def work():
            summary = self.edmunson(text)
            errors = self._detect_all_errors(summary)
            return summary, errors

        def callback(result):
            summary, errors = result
            self.output.delete(1.0, END)

            if self.rule_status["SALTO DE LÍNEA"].get() == 1:
                summary = summary.replace(". ", ".\n")

            # Insert summary text with highlights
            self.output.insert(END, summary)

            _SUGGESTION_RULES = {"ALTERNATIVAS", "DEFINICIONES"}
            highlight_errors = [e for e in errors
                                if e["rule_id"] not in ("FRASES LARGAS",)]
            long_sent_errors = [e for e in errors if e["rule_id"] == "FRASES LARGAS"]

            multi_eligible = [(e["start"], e["end"]) for e in highlight_errors
                              if e["rule_id"] not in _SUGGESTION_RULES]
            multi_spans = self._find_multi_error_spans(multi_eligible, len(summary))

            self.output.tag_configure("uncorrected", background="orange")
            self.output.tag_configure("suggestion", background="#a4c2f4")
            self.output.tag_configure("multi_error", background="#d85f5f")
            self.output.tag_configure("long_sentence", underline=True)

            for e in highlight_errors:
                tag = "suggestion" if e["rule_id"] in _SUGGESTION_RULES else "uncorrected"
                self._add_tag_skip_newlines(self.output, tag,
                                            e["start"], e["end"])

            for e in long_sent_errors:
                self._add_tag_skip_newlines(self.output, "long_sentence",
                                            e["start"], e["end"])

            for start, end in multi_spans:
                self._add_tag_skip_newlines(self.output, "multi_error", start, end)
            self.output.tag_raise("multi_error")

            # Append error messages below the summary
            if errors:
                error_messages = "\n".join(e["message"] for e in errors)
                self.output.insert(END, "\n\n" + error_messages)

            self._setup_tooltips(self.output, errors)

        self._run_async(work, callback)


window = Tk()
app = App(window)
window.mainloop()
