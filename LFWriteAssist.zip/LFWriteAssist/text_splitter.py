# text_splitter.py
import re

#def split_text(text):
#    split_pattern = re.compile(r'\.\.\.|[.,:;]')
#    return [segment.strip() for segment in re.split(split_pattern, text) if segment]
# text_splitter.py
#import re

def split_text(text):
    split_pattern = re.compile(r'\.\.\.|[.,:;]')
    segments = [segment.strip() for segment in re.split(split_pattern, text) if segment]
    return "\n".join(segments)
