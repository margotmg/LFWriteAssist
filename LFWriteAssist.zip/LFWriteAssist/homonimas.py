homofonas_homografas = {
'acerbo':'acervo',
'arrollo':'arroyo',
'baca':'vaca',
'barón':'varón',
'basto':'vasto',
'bello':'vello',
'bienes':'vienes',
'bobina':'bovina'
}
