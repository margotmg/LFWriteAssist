def count_syllables(word):
    vowels = "aeiouáéíóúü"
    word = word.lower()
    count = 0
    if word[0] in vowels:
        count += 1
    for index in range(1, len(word)):
        if word[index] in vowels and word[index-1] not in vowels:
            count += 1
    return count

def process_text(self, text):
    nlp = spacy.load('es_core_news_sm')
    doc = nlp(text)
    for token in doc:
        if count_syllables(token.text) >= 6:
            print(f"Warning: Found a long word '{token.text}'")

    #process_text() 
